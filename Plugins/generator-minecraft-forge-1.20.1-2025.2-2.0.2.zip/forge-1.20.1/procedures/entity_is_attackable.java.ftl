(${input$entity}.isAttackable())
