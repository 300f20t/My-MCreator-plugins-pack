(${input$entity}.isUnderWater())
