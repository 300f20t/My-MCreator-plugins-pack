(${input$entity}.getFirstPassenger())
