Utilisez ce champ pour définir les biomes, là où la génération doit avoir lieu.

Si la liste est vide, aucune restriction de biome ne sera définie et la génération se produira dans tous les biomes.

Fabric : Dû à une limitation de Fabric, seulement le premier tag sera utilisé. Afin d'utiliser plusieurs tags, créer simplement un nouveau tag contenant tous les tags désirés.