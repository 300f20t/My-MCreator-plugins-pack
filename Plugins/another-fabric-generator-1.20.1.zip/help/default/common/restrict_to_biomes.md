Use this field to define biomes, where the spawning should happen.

If the list is empty, no biome restriction will be set and spawning will
occur in all biomes.

Fabric: Due to a limitation of Fabric, only the first biome tag will be used. If you want to use multiple tags, simply create a tag containing all your desired tags.