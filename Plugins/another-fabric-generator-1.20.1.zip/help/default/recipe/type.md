This parameter controls in which crafting system your recipe will be available.

* Crafting is the Crafting Table.
* Smelting is Furnace recipe.
* Blasting is a recipe inside the Blast Furnace.
* Smoking is a recipe inside the Smoker.
* Stone cutting is a Stone Cutter recipe.
* Campfire cooking is a recipe for when we right-click on a Campfire.
* Smithing is a recipe inside the Smithing Table.
* Brewing is a recipe insite a Brewing Stand.  

**Fabric**: 
For the brewing stand recipes, tags are not allowed and potions have to be used for the input and the output.